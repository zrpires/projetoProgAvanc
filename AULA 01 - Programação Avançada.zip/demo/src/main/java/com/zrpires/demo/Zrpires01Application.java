package com.zrpires.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Zrpires01Application {

	public static void main(String[] args) {
		SpringApplication.run(Zrpires01Application.class, args);
	}

}
